Drag and drop this folder content to the root directory to update the game.
A new level and a new canon block will be added to the game.
Controls:

In Game:
Arrows / ZQSD (orientation), Space and Shift (forward/backward) for the reactors (according to the direction they are facing)
C to use canons

Building:
Left/Right Click to place/remove a block.
Arrow keys and mouse wheel to move the camera.

Objective: Destroy every enemy ship
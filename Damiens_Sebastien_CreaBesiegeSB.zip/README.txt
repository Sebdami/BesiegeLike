Controls:

Arrows / ZQSD (orientation), Space and Shift (forward/backward) for the reactors (according to the direction they are facing)
C to use canons

Objective: Destroy every enemy ship
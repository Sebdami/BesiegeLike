Controles:

Fl�ches / ZQSD (orientation), Espace et Shift (avancer/reculer) pour les r�acteurs (suivant leur orientation)
C pour les canons